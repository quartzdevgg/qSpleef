package com.QarthO.Spleef;

import org.bukkit.entity.Player;



public class ArenaEditor {
		
	Player player;
	Arena arena;
	boolean creating;
	EditorStep step;
	
	public ArenaEditor(Player editor, Arena arena, EditorStep step, boolean creating) {
		this.player = editor;
		this.arena = arena;
		this.creating = creating;
		this.step = step;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	
	
	
	
}
