package com.QarthO.Spleef.utils;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import com.QarthO.Spleef.Arena;
import com.QarthO.Spleef.Main;

public class Storage {

	public FileConfiguration arenasCfg;
	public File arenasFile;
	
	
	public Storage(Main plugin) {
		
		arenasFile = new File(plugin.getDataFolder(), "qArenas.yml");
		
		if(!arenasFile.exists()) {
			try {
				arenasFile.createNewFile();
				Bukkit.getServer().getConsoleSender().sendMessage(Language.CHAT_PREFIX.getMessage() + Language.ARENA_YML.getMessage());
			} catch(IOException e) {
				Bukkit.getServer().getConsoleSender().sendMessage(Language.CHAT_PREFIX.getMessage() + Language.ERROR_FAILED_ARENA_YML_CREATE.getMessage());
				Bukkit.getServer().getConsoleSender().sendMessage(e.getLocalizedMessage());
			}
		}
		
		arenasCfg = YamlConfiguration.loadConfiguration(arenasFile);
		
	}
	
	public void saveArena(Arena arena) {
		String name = arena.getName();
		if(name == null) {
			Bukkit.getServer().getConsoleSender().sendMessage(Language.CHAT_PREFIX.getMessage() + Language.ERROR_FAILED_ARENA_YML_SAVE.getMessage());
			return;
		}
		
		try {
			World world = arena.getWorld();
			if(world != null) arenasCfg.set(name + ".world", world.getName());
			
			Material material = arena.getFloorType();
			if(material != null) arenasCfg.set(name + ".floor", material.name());
			else arenasCfg.set(name + ".floor", "SNOW_BLOCK");
			
			Location loc = arena.getLoc1();
			saveLoc(loc, name + "zone.loc1");
			
			loc = arena.getLoc2();
			saveLoc(loc, name + "zone.loc2");
			
			loc = arena.getJoinLoc();
			saveLoc(loc, name + "zone.join");
			loc = arena.getSpecLoc();
			saveLoc(loc, name + "zone.spec");
			
			arenasCfg.save(arenasFile);
		} catch(IOException e) {
			Bukkit.getServer().getConsoleSender().sendMessage(Language.CHAT_PREFIX.getMessage() + Language.ERROR_FAILED_ARENA_YML_SAVE.getMessage());
		}
	}
	
	public Arena loadArena(String name) {
		if(!this.exists(name)) return null;
		
		World world = Bukkit.getWorld((String) arenasCfg.get(name + ".world"));
		Arena arena = new Arena(name, world);
		
		Material material = Material.getMaterial((String) arenasCfg.get(name + ".floor"));
		arena.setFloorType(material);
		
		Location loc;
		
		loc = this.loadLoc(world, name + "zone.loc1");
		arena.setLoc1(loc);
		
		loc = this.loadLoc(world, name + "zone.loc2");
		arena.setLoc2(loc);

		loc = this.loadLoc(world, name + "zone.join");
		arena.setSpecLoc(loc);

		loc = this.loadLoc(world, name + "zone.spec");
		arena.setJoinLoc(loc);
		
		return arena;
	}
	
	public boolean exists(String name) {
		for(String arenaName : this.getArenaList()) {
			if(arenaName.equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}
	
	public Set<String> getArenaList(){
		Set<String> keys = arenasCfg.getKeys(false);
		Set<String> arenaList = new HashSet<String>();
		for(String key : keys) {
			if(!key.contains(".")) {
				arenaList.add(key);
			}
			
		}
		Bukkit.getConsoleSender().sendMessage(Language.CHAT_PREFIX.getMessage() + "Arena List: " + arenaList);
		return arenaList;
	}
	
	public void saveLoc(Location loc, String path) {
		if(loc == null) return;
		arenasCfg.set(path + ".x", loc.getX());
		arenasCfg.set(path + ".y", loc.getY());
		arenasCfg.set(path + ".z", loc.getZ());
	}
	
	public Location loadLoc(World world, String path) {
		Location loc = new Location(world, 0, 0, 0);
		loc.setX(arenasCfg.getDouble(path + ".x"));
		loc.setX(arenasCfg.getDouble(path + ".y"));
		loc.setX(arenasCfg.getDouble(path + ".z"));
		return loc;
	
	}
	
	
}
