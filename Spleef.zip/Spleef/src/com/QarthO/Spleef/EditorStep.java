package com.QarthO.Spleef;

public enum EditorStep {
	LOC1,
	LOC2,
	JOIN,
	SPEC,
	MATERIAL
}
